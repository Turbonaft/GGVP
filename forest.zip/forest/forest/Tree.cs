﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forest
{
    public class Tree
    {
        public string Species { get; set; }
        public int Age { get; set; }
        public double Height { get; set; }
        public Image Image { get; set; } 

        public Tree(string species, int age, double height, Image image)
        {
            Species = species;
            Age = age;
            Height = height;
            Image = image; 
        }

        public void Grow()
        {
            Age++;
            Height += 1.0; 
        }
    }
}
