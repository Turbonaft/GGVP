﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace forest
{
    public partial class Form1 : Form
    {
        private Forest forest;

        public Form1()
        {
            InitializeComponent();
            forest = new Forest();
        }

        private void btnAddTree_Click(object sender, EventArgs e)
        {
            string species = txtSpecies.Text;
            int age = int.Parse(txtAge.Text);
            double height = double.Parse(txtHeight.Text);

            Image treeImage;
            switch (species.ToLower())
            {
                case "сосна":
                    treeImage = Image.FromFile("dub.png");
                    break;
                case "дуб":
                    treeImage = Image.FromFile("dub.png");
                    break;
                // Додайте інші види дерев
                default:
                    treeImage = Image.FromFile("dub.png"); // Зображення за замовчуванням
                    break;
            }

            Tree newTree = new Tree(species, age, height, treeImage);
            forest.AddTree(newTree);
            MessageBox.Show("Дерево додано!");
        }

        private void btnGrow_Click(object sender, EventArgs e)
        {
            forest.GrowTrees();
            
        }

        private void DisplayForest_Click(object sender, EventArgs e)
        {
            pictureBox1.Image = new Bitmap(pictureBox1.Width, pictureBox1.Height);
            using (Graphics g = Graphics.FromImage(pictureBox1.Image))
            {
                int x = 10; 
                int y = 10; 

                foreach (var tree in forest.Trees)
                {
                    g.DrawImage(tree.Image, new Rectangle(x, y, 100, 100)); 
                    y += 110; 
                }
            }
            pictureBox1.Refresh();
        }
    }
}
