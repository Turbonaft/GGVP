﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace forest
{
    public class Forest
    {
        public List<Tree> Trees { get; private set; }

        public Forest()
        {
            Trees = new List<Tree>();
        }

        public void AddTree(Tree tree)
        {
            Trees.Add(tree);
        }

        public void GrowTrees()
        {
            foreach (var tree in Trees)
            {
                tree.Grow();
            }
        }

        public string DisplayTrees()
        {
            string result = "";
            foreach (var tree in Trees)
            {
                result += $"{tree.Species} - Вік: {tree.Age}, Висота: {tree.Height}\n";
            }
            return result;
        }
    }
}
