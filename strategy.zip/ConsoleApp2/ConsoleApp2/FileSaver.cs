﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class FileSaver
    {
        private ISaveStrategy _strategy;

        public void SetStrategy(ISaveStrategy strategy)
        {
            _strategy = strategy;
        }

        public void SaveData(string data, string filePath)
        {
            _strategy.Save(data, filePath);
        }
    }
}
