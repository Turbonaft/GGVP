﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace ConsoleApp2
{
    public class XmlSaveStrategy : ISaveStrategy
    {
        public void Save(string data, string filePath)
        {
            var xml = new XElement("Content", data);
            xml.Save(filePath + ".xml");
        }
    }
}
