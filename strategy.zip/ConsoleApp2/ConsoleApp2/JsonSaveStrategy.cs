﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    public class JsonSaveStrategy : ISaveStrategy
    {
        public void Save(string data, string filePath)
        {
            var json = JsonSerializer.Serialize(new { content = data });
            File.WriteAllText(filePath + ".json", json);
        }
    }
}
