﻿using ConsoleApp2;
using System;

class Program
{
    static void Main(string[] args)
    {
        var saver = new FileSaver();

        Console.WriteLine("Введіть дані для збереження:");
        string data = Console.ReadLine();

        Console.WriteLine("Оберіть формат збереження (1 - TXT, 2 - JSON, 3 - XML):");
        string choice = Console.ReadLine();

        switch (choice)
        {
            case "1":
                saver.SetStrategy(new TxtSaveStrategy());
                break;
            case "2":
                saver.SetStrategy(new JsonSaveStrategy());
                break;
            case "3":
                saver.SetStrategy(new XmlSaveStrategy());
                break;
            default:
                Console.WriteLine("Невірний вибір.");
                return;
        }

        saver.SaveData(data, "SavedFile");

        Console.WriteLine("Файл успішно збережено.");
    }
}