﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp1
{
    public partial class Form1: Form
    {
        private readonly Caretaker _caretaker = new Caretaker();
        private readonly Originator _originator = new Originator();
        public Form1()
        {
            InitializeComponent();
            _caretaker.SaveState(_originator.CreateMemento(textBox1.Text));
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            _caretaker.SaveState(_originator.CreateMemento(textBox1.Text));
        }

        private void undoButton_Click(object sender, EventArgs e)
        {
            var memento = _caretaker.Undo();
            if (memento != null)
            {
                textBox1.TextChanged -= textBox1_TextChanged;
                textBox1.Text = memento.Text;
                textBox1.TextChanged += textBox1_TextChanged;
            }
        }
    }
    public class Memento
    {
        public string Text { get; }
        public Memento(string text) => Text = text;
    }

    public class Originator
    {
        public Memento CreateMemento(string text) => new Memento(text);
    }

    public class Caretaker
    {
        private readonly Stack<Memento> _history = new Stack<Memento>();

        public void SaveState(Memento memento)
        {
            _history.Push(memento);
        }

        public Memento Undo()
        {
            if (_history.Count > 1)
            {
                _history.Pop(); // поточний стан
                return _history.Peek(); // попередній
            }
            return null;
        }
    }
}
