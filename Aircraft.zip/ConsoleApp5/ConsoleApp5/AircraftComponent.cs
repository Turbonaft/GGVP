﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp5
{
    public interface AircraftComponent
    {
        string Name { get; }
        void Display(int indent = 0); 
    }

    public class AircraftPart : AircraftComponent
    {
        public string Name { get; private set; }

        public AircraftPart(string name)
        {
            Name = name;
        }

        public void Display(int indent = 0)
        {
            Console.WriteLine($"{new string(' ', indent)}- {Name}");
        }
    }

    public class AircraftComposite : AircraftComponent
    {
        public string Name { get; private set; }
        private readonly List<AircraftComponent> _components = new();

        public AircraftComposite(string name)
        {
            Name = name;
        }

        public void Add(AircraftComponent component)
        {
            _components.Add(component);
        }

        public void Remove(AircraftComponent component)
        {
            _components.Remove(component);
        }

        public void Display(int indent = 0)
        {
            Console.WriteLine($"{new string(' ', indent)}+ {Name}");
            foreach (var component in _components)
            {
                component.Display(indent + 2);
            }
        }
    }
}
