﻿using ConsoleApp5;

class Program
{
    static void Main()
    {
        var leftWing = new AircraftPart("Ліве крило");
        var rightWing = new AircraftPart("Праве крило");
        var engine1 = new AircraftPart("Двигун №1");
        var engine2 = new AircraftPart("Двигун №2");
        var tail = new AircraftPart("Хвіст");

        var wings = new AircraftComposite("Крила");
        wings.Add(leftWing);
        wings.Add(rightWing);

        var engines = new AircraftComposite("Двигуни");
        engines.Add(engine1);
        engines.Add(engine2);

        var fuselage = new AircraftComposite("Корпус");
        fuselage.Add(wings);
        fuselage.Add(engines);
        fuselage.Add(tail);

        Console.WriteLine("Структура літака:");
        fuselage.Display();
    }
}