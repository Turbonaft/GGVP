﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    public class LandingPageWebsite : WebsiteBuilder
    {
        protected override string AddHeader() => "Landing Page Header\n";
        protected override string AddNavigation() => "Minimal Nav\n";
        protected override string AddMainContent() => "Call to Action Section\n";
        protected override string AddFooter() => "Landing Page Footer\n";
    }
}
