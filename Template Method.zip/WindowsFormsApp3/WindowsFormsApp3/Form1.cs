﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApp3
{
    public partial class Form1: Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.AddRange(new string[] { "Blog", "Shop", "Landing Page" });
        }

        private void buttonBuild_Click(object sender, EventArgs e)
        {
            WebsiteBuilder builder = null;

            switch (comboBox1.SelectedItem?.ToString())
            {
                case "Blog":
                    builder = new BlogWebsite();
                    break;
                case "Shop":
                    builder = new ShopWebsite();
                    break;
                case "Landing Page":
                    builder = new LandingPageWebsite();
                    break;
            }

            if (builder != null)
            {
                string result = builder.BuildWebsite();
                textBoxOutput.Text = result;
            }
            else
            {
                MessageBox.Show("Please select a website type.");
            }
        }
    }
}
