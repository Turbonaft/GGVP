﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    public abstract class WebsiteBuilder
    {
        public string BuildWebsite()
        {
            string result = "";
            result += AddHeader();
            result += AddNavigation();
            result += AddMainContent();
            result += AddFooter();
            return result;
        }

        protected abstract string AddHeader();
        protected abstract string AddNavigation();
        protected abstract string AddMainContent();
        protected abstract string AddFooter();
    }
}
