﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    public class BlogWebsite : WebsiteBuilder
    {
        protected override string AddHeader() => "Blog Header\n";
        protected override string AddNavigation() => "Blog Navigation\n";
        protected override string AddMainContent() => "Blog Posts Section\n";
        protected override string AddFooter() => "Blog Footer\n";
    }
}
