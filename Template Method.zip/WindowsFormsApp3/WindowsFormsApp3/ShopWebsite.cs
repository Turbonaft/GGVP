﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp3
{
    public class ShopWebsite : WebsiteBuilder
    {
        protected override string AddHeader() => "Shop Header\n";
        protected override string AddNavigation() => "Product Categories\n";
        protected override string AddMainContent() => "Product Listings\n";
        protected override string AddFooter() => "Shop Footer\n";
    }
}
