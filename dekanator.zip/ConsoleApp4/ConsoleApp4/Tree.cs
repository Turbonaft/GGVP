﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    public interface ITreeNode
    {
        void Display();
    }

    // Реализация обычного узла дерева
    public class TreeNode : ITreeNode
    {
        public string Name { get; }

        public TreeNode(string name)
        {
            Name = name;
        }

        public void Display()
        {
            Console.WriteLine(Name);
        }
    }

    // Абстрактный декоратор
    public abstract class TreeDecorator : ITreeNode
    {
        protected ITreeNode _treeNode;

        protected TreeDecorator(ITreeNode treeNode)
        {
            _treeNode = treeNode;
        }

        public virtual void Display()
        {
            _treeNode.Display();
        }
    }

    // Конкретный декоратор для добавления цвета
    public class ColoredTreeDecorator : TreeDecorator
    {
        private readonly ConsoleColor _color;

        public ColoredTreeDecorator(ITreeNode treeNode, ConsoleColor color) : base(treeNode)
        {
            _color = color;
        }

        public override void Display()
        {
            Console.ForegroundColor = _color;
            _treeNode.Display();
            Console.ResetColor();
        }
    }
}
