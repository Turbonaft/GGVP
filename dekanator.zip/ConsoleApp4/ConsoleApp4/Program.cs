﻿using ConsoleApp4;

class Program
{
    static void Main()
    {
        // Базовый узел дерева
        ITreeNode node = new TreeNode("Root Node");

        // Ввод цвета от пользователя
        Console.WriteLine("Введите желаемый цвет (например: Red, Green, Blue):");
        string colorInput = Console.ReadLine();

        if (Enum.TryParse<ConsoleColor>(colorInput, true, out ConsoleColor chosenColor))
        {
            // Добавление декоратора цвета
            node = new ColoredTreeDecorator(node, chosenColor);
        }
        else
        {
            Console.WriteLine("Некорректный цвет. Будет использован стандартный цвет.");
        }

        // Вывод узла дерева с цветом
        node.Display();
    }
}
