﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public class OnlineStoreService : IPaymentService
    {
        public void ProcessPayment(string cardType, string paymentType)
        {
            MessageBox.Show($"Оплата через інтернет-магазин з картки {cardType}");
        }
    }

    public class UtilitiesService : IPaymentService
    {
        public void ProcessPayment(string cardType, string paymentType)
        {
            MessageBox.Show($"Оплата комунальних послуг з картки {cardType}");
        }
    }
}
