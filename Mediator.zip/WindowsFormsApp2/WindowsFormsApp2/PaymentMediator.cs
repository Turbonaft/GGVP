﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public class PaymentMediator
    {
        private Dictionary<string, IPaymentService> services = new Dictionary<string, IPaymentService>();

        public void RegisterService(string paymentType, IPaymentService service)
        {
            services[paymentType] = service;
        }

        public void Pay(string cardType, string paymentType)
        {
            if (services.ContainsKey(paymentType))
            {
                services[paymentType].ProcessPayment(cardType, paymentType);
            }
            else
            {
                MessageBox.Show("Немає відповідного сервісу для цього виду оплати.");
            }
        }
    }
}
