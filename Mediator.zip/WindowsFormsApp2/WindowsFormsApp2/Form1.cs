﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp2
{
    public partial class Form1: Form
    {
        private PaymentMediator mediator;
        public Form1()
        {
            InitializeComponent();

            mediator = new PaymentMediator();
            mediator.RegisterService("Інтернет-магазин", new OnlineStoreService());
            mediator.RegisterService("Комунальні послуги", new UtilitiesService());

            comboBoxCard.Items.AddRange(new string[] { "Visa", "MasterCard" });
            comboBoxPayment.Items.AddRange(new string[] { "Інтернет-магазин", "Комунальні послуги" });
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void buttonPay_Click(object sender, EventArgs e)
        {
            var cardType = comboBoxCard.SelectedItem?.ToString();
            var paymentType = comboBoxPayment.SelectedItem?.ToString();

            if (cardType != null && paymentType != null)
            {
                mediator.Pay(cardType, paymentType);
            }
            else
            {
                MessageBox.Show("Будь ласка, оберіть картку та тип оплати.");
            }
        }
    }
}
