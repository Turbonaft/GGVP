﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp6
{
    public interface IBankConsultationService
    {
        string GetAnswer(string question);
    }

    public class BankConsultationService : IBankConsultationService
    {
        private readonly Dictionary<string, string> _answers = new Dictionary<string, string>
        {
            { "Який ваш робочий час?", "Наш робочий час з понеділка по п'ятницю з 9:00 до 17:00." },
            { "Які документи потрібні для відкриття рахунку?", "Для відкриття рахунку потрібен паспорт і підтвердження адреси." },
            { "Які ваші процентні ставки?", "Наша поточна процентна ставка становить 3,5% річних для ощадних рахунків." }
        };

        public string GetAnswer(string question)
        {
            return _answers.ContainsKey(question) ? _answers[question] : "Вибачте, я не маю відповіді на це запитання.";
        }
    }

    public class BankConsultationProxy : IBankConsultationService
    {
        private readonly BankConsultationService _realService = new BankConsultationService();

        public string GetAnswer(string question)
        {
            var allowedQuestions = new HashSet<string>
            {
                "Які у вас години роботи?",
                "Які документи потрібні для відкриття рахунку?",
                "Які у вас процентні ставки?"
            };

            if (allowedQuestions.Contains(question))
            {
                return _realService.GetAnswer(question);
            }

            return "Це питання не підтримується службою.";
        }
    }
}
