﻿using ConsoleApp6;

class Program
{
    static void Main(string[] args)
    {
        IBankConsultationService proxy = new BankConsultationProxy();

        Console.WriteLine("Ласкаво просимо до служби банківської консультації!");
        Console.WriteLine("Ви можете поставити наступні питання:");
        Console.WriteLine("- Який ваш робочий час?");
        Console.WriteLine("- Які документи потрібні для відкриття рахунку?");
        Console.WriteLine("- Які ваші процентні ставки?");
        Console.WriteLine();

        while (true)
        {
            Console.Write("Введіть своє запитання (або введіть «вихід», щоб вийти): ");
            string question = Console.ReadLine();

            if (question.ToLower() == "вихід")
            {
                Console.WriteLine("Дякуємо за користування сервісом. До побачення!");
                break;
            }

            string answer = proxy.GetAnswer(question);
            Console.WriteLine($"Answer: {answer}");
            Console.WriteLine();
        }
    }
}