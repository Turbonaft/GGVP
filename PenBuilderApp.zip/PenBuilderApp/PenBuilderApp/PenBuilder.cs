﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenBuilderApp
{
    public class PenBuilder
    {
        private Pen penPrototype;

        public void SetColor(string color)
        {
            if (penPrototype == null)
                penPrototype = new Pen();
            penPrototype.Color = color;
        }

        public void SetTipSize(int size)
        {
            if (penPrototype == null)
                penPrototype = new Pen();
            penPrototype.TipSize = size;
        }

        public Pen CreatePen()
        {
            return penPrototype.Clone();
        }
    }
}
