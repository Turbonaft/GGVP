﻿namespace PenBuilderApp
{
    partial class MainForm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.Color = new System.Windows.Forms.Label();
            this.Tip_Size = new System.Windows.Forms.Label();
            this.txtColor = new System.Windows.Forms.TextBox();
            this.txtTipSize = new System.Windows.Forms.TextBox();
            this.lstPens = new System.Windows.Forms.ListBox();
            this.btnCreatePen = new System.Windows.Forms.Button();
            this.btnClonePen = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Color
            // 
            this.Color.AutoSize = true;
            this.Color.Location = new System.Drawing.Point(12, 19);
            this.Color.Name = "Color";
            this.Color.Size = new System.Drawing.Size(31, 13);
            this.Color.TabIndex = 0;
            this.Color.Text = "Color";
            // 
            // Tip_Size
            // 
            this.Tip_Size.AutoSize = true;
            this.Tip_Size.Location = new System.Drawing.Point(12, 102);
            this.Tip_Size.Name = "Tip_Size";
            this.Tip_Size.Size = new System.Drawing.Size(45, 13);
            this.Tip_Size.TabIndex = 1;
            this.Tip_Size.Text = "Tip Size";
            // 
            // txtColor
            // 
            this.txtColor.Location = new System.Drawing.Point(15, 50);
            this.txtColor.Name = "txtColor";
            this.txtColor.Size = new System.Drawing.Size(100, 20);
            this.txtColor.TabIndex = 2;
            // 
            // txtTipSize
            // 
            this.txtTipSize.Location = new System.Drawing.Point(15, 132);
            this.txtTipSize.Name = "txtTipSize";
            this.txtTipSize.Size = new System.Drawing.Size(100, 20);
            this.txtTipSize.TabIndex = 3;
            // 
            // lstPens
            // 
            this.lstPens.FormattingEnabled = true;
            this.lstPens.Location = new System.Drawing.Point(390, 50);
            this.lstPens.Name = "lstPens";
            this.lstPens.Size = new System.Drawing.Size(283, 251);
            this.lstPens.TabIndex = 4;
            // 
            // btnCreatePen
            // 
            this.btnCreatePen.Location = new System.Drawing.Point(172, 47);
            this.btnCreatePen.Name = "btnCreatePen";
            this.btnCreatePen.Size = new System.Drawing.Size(75, 23);
            this.btnCreatePen.TabIndex = 5;
            this.btnCreatePen.Text = "CreatePen";
            this.btnCreatePen.UseVisualStyleBackColor = true;
            this.btnCreatePen.Click += new System.EventHandler(this.btnCreatePen_Click_1);
            // 
            // btnClonePen
            // 
            this.btnClonePen.Location = new System.Drawing.Point(172, 76);
            this.btnClonePen.Name = "btnClonePen";
            this.btnClonePen.Size = new System.Drawing.Size(75, 23);
            this.btnClonePen.TabIndex = 6;
            this.btnClonePen.Text = "ClonePen";
            this.btnClonePen.UseVisualStyleBackColor = true;
            this.btnClonePen.Click += new System.EventHandler(this.btnClonePen_Click_1);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClonePen);
            this.Controls.Add(this.btnCreatePen);
            this.Controls.Add(this.lstPens);
            this.Controls.Add(this.txtTipSize);
            this.Controls.Add(this.txtColor);
            this.Controls.Add(this.Tip_Size);
            this.Controls.Add(this.Color);
            this.Name = "MainForm";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Color;
        private System.Windows.Forms.Label Tip_Size;
        private System.Windows.Forms.TextBox txtColor;
        private System.Windows.Forms.TextBox txtTipSize;
        private System.Windows.Forms.ListBox lstPens;
        private System.Windows.Forms.Button btnCreatePen;
        private System.Windows.Forms.Button btnClonePen;
    }
}

