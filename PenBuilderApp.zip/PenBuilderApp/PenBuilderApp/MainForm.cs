﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PenBuilderApp
{
    public partial class MainForm : Form
    {
        private PenBuilder penBuilder;
        private List<Pen> pens;

        public MainForm()
        {
            InitializeComponent();
            penBuilder = new PenBuilder();
            pens = new List<Pen>();
        }

        private void UpdatePenList()
        {
            lstPens.Items.Clear();
            foreach (var pen in pens)
            {
                lstPens.Items.Add(pen.GetDetails());
            }
        }

        private void btnCreatePen_Click_1(object sender, EventArgs e)
        {
            penBuilder.SetColor(txtColor.Text);
            penBuilder.SetTipSize(int.Parse(txtTipSize.Text));
            Pen newPen = penBuilder.CreatePen();
            pens.Add(newPen);
            UpdatePenList();
        }

        private void btnClonePen_Click_1(object sender, EventArgs e)
        {
            if (pens.Count > 0)
            {
                Pen clonedPen = pens[pens.Count - 1].Clone();
                pens.Add(clonedPen);
                UpdatePenList();
            }
        }
    }
}
