﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PenBuilderApp
{
    public class Pen
    {
        public string Color { get; set; }
        public int TipSize { get; set; }

        public Pen Clone()
        {
            return new Pen { Color = this.Color, TipSize = this.TipSize };
        }

        public string GetDetails()
        {
            return $"Color: {Color}, Tip Size: {TipSize}";
        }
    }
}
