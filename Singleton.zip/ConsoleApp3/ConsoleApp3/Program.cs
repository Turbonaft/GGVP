﻿using Singleton;
class Program
{
    static void Main(string[] args)
    {
        dbManager.Instance.Connect();

        DocumentSaver.Instance.SaveDocument("Документ 1");

        Logger.Instance.Log("Пользователь выполнил действие.");
    }
}