﻿namespace FlowerBouquetLibrary
{
    public interface IFlowerBouquet
    {
        string GetBouquetDetails();
    }
}
