﻿using FlowerBouquetLibrary;

class Program
{
    static void Main(string[] args)
    {
        BouquetFactory factory = new BouquetFactory();
        IFlowerBouquet birthdayBouquet = factory.GetBouquet("Birthday");
        Console.WriteLine(birthdayBouquet.GetBouquetDetails());
    }
}
