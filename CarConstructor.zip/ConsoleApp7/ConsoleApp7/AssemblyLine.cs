﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    public class AssemblyLine
    {
        private readonly IAssemblyStep _firstStep;

        public AssemblyLine()
        {
            var engineStep = new EngineStep();
            var wheelsStep = new WheelsStep();
            var interiorStep = new InteriorStep();

            engineStep.SetNext(wheelsStep);
            wheelsStep.SetNext(interiorStep);

            _firstStep = engineStep;
        }

        public void Assemble(Car car)
        {
            _firstStep.Handle(car);
        }
    }
}
