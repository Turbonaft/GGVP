﻿using ConsoleApp7;

public interface IAssemblyStep
{
    void SetNext(IAssemblyStep nextStep);
    void Handle(Car car);
}
class Program
{
    static void Main()
    {
        var assemblyLine = new AssemblyLine();

        Car sedan = new Car("Sedan");
        assemblyLine.Assemble(sedan);
        sedan.ShowComponents();

        Car suv = new Car("SUV");
        assemblyLine.Assemble(suv);
        suv.ShowComponents();
    }
}