﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    public class EngineStep : AssemblyStep
    {
        public override void Handle(Car car)
        {
            if (car.Model == "Sedan" || car.Model == "SUV")
            {
                car.AddComponent("Engine V6");
            }
            else
            {
                car.AddComponent("Engine V4");
            }
            base.Handle(car);
        }
    }

    public class WheelsStep : AssemblyStep
    {
        public override void Handle(Car car)
        {
            car.AddComponent(car.Model == "SUV" ? "Off-road Wheels" : "Standard Wheels");
            base.Handle(car);
        }
    }

    public class InteriorStep : AssemblyStep
    {
        public override void Handle(Car car)
        {
            car.AddComponent("Leather Seats");
            base.Handle(car);
        }
    }
}
