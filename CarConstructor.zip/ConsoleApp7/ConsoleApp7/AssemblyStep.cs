﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    public abstract class AssemblyStep : IAssemblyStep
    {
        protected IAssemblyStep NextStep;

        public void SetNext(IAssemblyStep nextStep)
        {
            NextStep = nextStep;
        }

        public virtual void Handle(Car car)
        {
            NextStep?.Handle(car);
        }
    }
}
