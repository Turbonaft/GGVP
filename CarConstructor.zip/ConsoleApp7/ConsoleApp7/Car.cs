﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp7
{
    public class Car
    {
        public string Model { get; }
        public List<string> Components { get; }

        public Car(string model)
        {
            Model = model;
            Components = new List<string>();
        }

        public void AddComponent(string component)
        {
            Components.Add(component);
        }

        public void ShowComponents()
        {
            Console.WriteLine($"Car Model: {Model}");
            Console.WriteLine("Components Installed: " + string.Join(", ", Components));
        }
    }
}
